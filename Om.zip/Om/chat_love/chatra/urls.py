# chat/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),  # Login page
    path('', views.home, name='home'),#Chat Page
    path('logout/', views.user_logout, name='logout'), #Logout Page
]

