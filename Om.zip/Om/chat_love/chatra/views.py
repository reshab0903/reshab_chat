# myapp/views.py
from django.shortcuts import render, redirect
from django.contrib.auth import logout
from .models import Message
from django.http import HttpResponse
# myapp/views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from .models import Message

# View for handling login
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            # If form is valid, authenticate and login the user
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')  # Redirect to the home (chat) page after login
            else:
                return render(request, 'chat/login.html', {'form': form, 'error': 'Invalid credentials'})
    else:
        form = AuthenticationForm()
    return render(request, 'chat/login.html', {'form': form})

# View for displaying the chat page (protected by login_required)
@login_required
def home(request):
    if request.method == 'POST':
        sender = request.user.username  # Automatically fetches the logged-in user's username
        receiver = 'Reshab' if sender == 'Asmat' else 'Asmat'  # Automatically determine the receiver
        content = request.POST.get('content')

        # Create and save the new message
        message = Message(sender=sender, receiver=receiver, content=content)
        message.save()

        return redirect('home')  # Redirect back to the chat page after saving the message

    messages = Message.objects.all().order_by('timestamp')
    return render(request, 'chat/chat.html', {'messages': messages})

def user_logout(request):
    logout(request)
    return redirect('login')  # Redirect to login page or homepage


